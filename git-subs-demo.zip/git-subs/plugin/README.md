A demo repository for subtree investigation, acting as the central code for the subtree, to be blended in "container" repos.

Also see the `subtree-demo-main` repo for the companion demo repo, acting as the main project code that blends this repo in as a subtree.
