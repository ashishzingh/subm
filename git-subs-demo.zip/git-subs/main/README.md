A demo repository for subtree investigation, acting as the main repository that blends a plugin in as a subtree.

Also see the `subtree-demo-plugin` repo for the companion demo repo, acting as the central code for the subtree.
